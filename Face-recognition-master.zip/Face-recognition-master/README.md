# Face-Recognition
## Used HOG for face detection and Facenet for feature extraction.
## Reference:
1. Deep face recognition with Keras, Dlib and OpenCV http://krasserm.github.io/2018/02/07/deep-face-recognition/
2. https://github.com/ageitgey/face_recognition
